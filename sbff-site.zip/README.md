# Your Sports BFF (S*BFF)

Content, platforms, and experiences for the modern female sports fan.

## Pages
- `/` — Homepage
- `/bff-brief` — BFF Brief
- `/about` — About
- `/account` — Member Account (signup flow + dashboard)
